# Import necessary libraries
from flask import Flask, render_template, request
import spotipy
from spotipy.oauth2 import SpotifyClientCredentials

# Set up Spotipy client credentials
client_id = '18815aa515564d738bfd8bc8a1059557'
client_secret = 'e99d268258724eaf9016d533fc9bd512'
client_credentials_manager = SpotifyClientCredentials(client_id=client_id, client_secret=client_secret) # create an instance of SpotifyClientCredentials class with client_id and client_secret
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager) # create an instance of Spotipy class with client credentials manager

# Initialize Flask app
app = Flask(__name__)

# Define root route
@app.route('/')
def index():
    return render_template('index.html') # render index.html template

# Define search artist route
@app.route('/search_artist', methods=['GET', 'POST'])
def search_artist():
    if request.method == 'POST': # if request is POST
        artist_name = request.form['artist_name'] # get the artist name from the form
        results = sp.search(q=artist_name, type="artist", limit=5) # search for artists using the spotipy client
        artists = results["artists"]["items"] # get the artists from the search results
        if len(artists) > 0: # if artists are found
            return render_template('search_artist.html', artists=artists) # render search_artist.html template with artists as argument
        else:
            return render_template('search_artist.html', error='No artists found.') # render search_artist.html template with error message
    else:
        return render_template('search_artist.html') # render search_artist.html template

# Define fetch audio features route
@app.route('/fetch_audio_features', methods=['GET', 'POST'])
def fetch_audio_features():
    if request.method == 'POST': # if request is POST
        track_name = request.form['track_name'] # get the track name from the form
        artist_name = request.form['artist_name'] # get the artist name from the form
        results = sp.search(q=f"track:{track_name} artist:{artist_name}", type="track", limit=1) # search for tracks using the spotipy client
        tracks = results["tracks"]["items"] # get the tracks from the search results
        if len(tracks) > 0: # if tracks are found
            track_id = tracks[0]["id"] # get the track ID of the first track
            features = sp.audio_features([track_id]) # get audio features of the track using the track ID
            if features: 
                audio_features = features[0] # get audio features of the track
                return render_template('fetch_audio_features.html', audio_features=audio_features) # render fetch_audio_features.html template with audio features as argument
            else:
                return render_template('fetch_audio_features.html', error='Audio features not found for the given track name and artist name.') # render fetch_audio_features.html template with error message
        else:
            return render_template('fetch_audio_features.html', error='No tracks found for the given track name and artist name.') # render fetch_audio_features.html template with error message
    else:
        return render_template('fetch_audio_features.html') # render fetch_audio_features.html template

# Define retrieve artist albums route
@app.route('/retrieve_artist_albums', methods=['GET', 'POST'])
def retrieve_artist_albums():
    if request.method == 'POST': # if request is POST
        artist_name = request.form['artist_name'] # get the artist name from the form
        results = sp.search(q=artist_name, type="artist", limit=1) # search for artists using the spotipy client
        artists = results["artists"]["items"] # get the artists from the search results
        if len(artists) > 0: # if artists are found
            artist_id = artists[0]["id"] # get the artist ID of the first artist
            results = sp.artist_albums(artist_id, album_type="album", limit=10) # get the albums of the artist using the artist ID
            albums = results["items"] # get the albums from the search results
            if len(albums) > 0: # if albums are found
                return render_template('retrieve_artist_albums.html', albums=albums) # render retrieve_artist_albums.html template with albums as argument
            else:
                return render_template('retrieve_artist_albums.html', error='No albums found for the given artist name.') # render retrieve_artist_albums.html template with error message
        else:
            return render_template('retrieve_artist_albums.html', error='No artist found for the given artist name.') # render retrieve_artist_albums.html template with error message
    else:
        return render_template('retrieve_artist_albums.html') # render retrieve_artist_albums.html template

# Run Flask app
if __name__ == '__main__':
    app.run(debug=True) # run the Flask app in debug mode